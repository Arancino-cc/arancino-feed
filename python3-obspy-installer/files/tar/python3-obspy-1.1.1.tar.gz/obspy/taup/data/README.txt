To (re)create models from all '.tvel' files in this folder run 'taup_create.py'.
